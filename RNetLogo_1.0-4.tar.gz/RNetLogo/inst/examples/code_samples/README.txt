Please find a short usage example of the functions offered by the RNetLogo package in the respective folder.
